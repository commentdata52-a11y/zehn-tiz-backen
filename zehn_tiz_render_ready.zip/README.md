# ذهن تیز — بک‌اند نسخه ۱

بک‌اند قابل اجرا با FastAPI، SQLite (قابل جایگزینی با PostgreSQL)، احراز هویت JWT، رمز عبور PBKDF2، بانک سؤال، امتیاز و سکه، جدول رتبه‌بندی، پنل مدیریت و دوئل آنلاین دونفره با WebSocket.

## اجرا

Python 3.11+ لازم است.

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
cp .env.example .env  # Windows: copy .env.example .env
```

مقادیر `SECRET_KEY` (حداقل ۳۲ کاراکتر تصادفی)، `ADMIN_EMAIL` و `ADMIN_PASSWORD` (حداقل ۱۲ کاراکتر) را در `.env` تنظیم کنید. سپس:

```bash
# Linux/macOS
set -a; source .env; set +a
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

در ویندوز متغیرهای فایل `.env` را در محیط تعریف کنید، یا `python run.py` را اجرا کنید (بارگذاری خودکار فایل .env).

آدرس مستندات API: http://127.0.0.1:8000/docs

## مسیرهای مهم

- `POST /api/auth/register` — ثبت‌نام (بدون امکان تعیین نقش مدیر)
- `POST /api/auth/login` — ورود و دریافت Bearer JWT
- `GET /api/me` — پروفایل
- `GET /api/questions?category=general` — دریافت سؤالات بدون پاسخ صحیح
- `POST /api/answers` — پاسخ، XP و سکه (هر سؤال یک‌بار امتیاز)
- `GET /api/leaderboard` — رتبه‌بندی
- `GET/POST /api/admin/questions` و `DELETE /api/admin/questions/{id}` — مدیریت بانک سؤال
- `GET /api/admin/users` — کاربران
- `POST /api/rooms`، `POST /api/rooms/{code}/join`، `POST /api/rooms/{code}/start` — اتاق دوئل
- `GET /api/rooms/{code}/current`، `POST /api/rooms/{code}/answer`، `POST /api/rooms/{code}/next` — مسابقه
- `WS /ws/rooms/{code}?token=JWT` — دریافت رویدادهای مسابقه

برای درخواست‌های حفاظت‌شده هدر `Authorization: Bearer <token>` لازم است.

## ملاحظات

- «دوئل وای‌فای» این نسخه در واقع ارتباط از طریق یک سرور مشترک روی LAN یا اینترنت است، نه کشف خودکار دستگاه‌ها و نه P2P مستقیم. دو گوشی باید به سرور دسترسی داشته باشند.
- این نسخه یک **پایه عملیاتی توسعه** است، نه محصول آماده انتشار عمومی: برای انتشار نیاز به HTTPS/WSS، محدودسازی نرخ درخواست، مدیریت تراکنش همزمان اتاق‌ها، ذخیره رویدادها، تست امنیتی، مدیریت نشت توکن و WebSocket broker در اجرای چندپردازشی دارد.
- برای امنیت، هیچ رمز مستری در HTML یا API وجود ندارد؛ حساب مدیر فقط با متغیرهای محیطی در نخستین راه‌اندازی ساخته می‌شود.
- سؤال‌های اولیه را از حساب مدیر در `/docs` اضافه کنید. بدون سؤال، ایجاد مسابقه ممکن نیست.
- فرانت‌اند HTML قدیمی باید جداگانه به این API متصل شود؛ اتصال آن در این بسته انجام نشده است.
