# Deploy to Render

1. Create a new GitHub repository and upload the contents of this directory (not the parent directory).
2. In Render choose New > Blueprint and select that repository.
3. Review the plan: free Python web service.
4. Provide ADMIN_EMAIL and a unique ADMIN_PASSWORD of at least 12 characters in Render; never commit secrets.
5. Deploy and verify https://<service>.onrender.com/health and /docs.

WARNING: SQLite on Render free web service uses ephemeral disk and game data may be lost on restart/redeploy. Use persistent PostgreSQL for real players. The backend also needs frontend integration and production security review.
