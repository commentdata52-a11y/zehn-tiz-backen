"""Zehn Tiz API: accounts, question bank, progression and real-time duels."""
import os, json, time, secrets, hashlib, hmac, random
from datetime import datetime, timezone, timedelta
from contextlib import asynccontextmanager
from typing import Optional
import jwt
from fastapi import FastAPI, HTTPException, Depends, WebSocket, WebSocketDisconnect, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, Column, Integer, String, Boolean, ForeignKey, DateTime, UniqueConstraint, select, func
from sqlalchemy.orm import declarative_base, sessionmaker, Session

SECRET = os.environ.get('SECRET_KEY', '')
if len(SECRET) < 32:
    raise RuntimeError('Set SECRET_KEY to at least 32 random characters before startup')
DB_URL = os.environ.get('DATABASE_URL', 'sqlite:///./zehn_tiz.db')
engine = create_engine(DB_URL, connect_args={'check_same_thread': False} if DB_URL.startswith('sqlite') else {}, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
Base = declarative_base()

def now(): return datetime.now(timezone.utc)

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    username = Column(String(40), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(300), nullable=False)
    is_admin = Column(Boolean, default=False, nullable=False)
    xp = Column(Integer, default=0, nullable=False)
    coins = Column(Integer, default=100, nullable=False)
    created_at = Column(DateTime(timezone=True), default=now)

class Question(Base):
    __tablename__ = 'questions'
    id = Column(Integer, primary_key=True)
    category = Column(String(50), nullable=False, index=True)
    prompt = Column(String(1000), nullable=False)
    options_json = Column(String(3000), nullable=False)
    correct_index = Column(Integer, nullable=False)
    difficulty = Column(Integer, default=1)
    active = Column(Boolean, default=True)

class Attempt(Base):
    __tablename__ = 'attempts'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False, index=True)
    question_id = Column(Integer, ForeignKey('questions.id'), nullable=False)
    correct = Column(Boolean, nullable=False)
    earned_xp = Column(Integer, default=0)
    created_at = Column(DateTime(timezone=True), default=now)

class Match(Base):
    __tablename__ = 'matches'
    id = Column(Integer, primary_key=True)
    room_code = Column(String(8), unique=True, index=True)
    host_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    guest_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    status = Column(String(20), default='waiting')
    category = Column(String(50), default='general')
    question_count = Column(Integer, default=5)
    time_limit = Column(Integer, default=15)
    questions_json = Column(String(3000), default='[]')
    current_round = Column(Integer, default=0)
    round_started_at = Column(Integer, default=0)
    host_score = Column(Integer, default=0)
    guest_score = Column(Integer, default=0)

class MatchAnswer(Base):
    __tablename__ = 'match_answers'
    id = Column(Integer, primary_key=True)
    match_id = Column(Integer, ForeignKey('matches.id'), nullable=False)
    round_index = Column(Integer, nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    choice = Column(Integer, nullable=False)
    __table_args__ = (UniqueConstraint('match_id','round_index','user_id'),)

def hash_password(p):
    salt = secrets.token_bytes(16)
    derived = hashlib.pbkdf2_hmac('sha256', p.encode(), salt, 310000)
    return f'pbkdf2_sha256$310000${salt.hex()}${derived.hex()}'

def verify_password(p, encoded):
    try:
        alg, iterations, salt, digest = encoded.split('$')
        if alg != 'pbkdf2_sha256': return False
        candidate = hashlib.pbkdf2_hmac('sha256', p.encode(), bytes.fromhex(salt), int(iterations))
        return hmac.compare_digest(candidate, bytes.fromhex(digest))
    except (ValueError, TypeError): return False

def token_for(user):
    return jwt.encode({'sub':str(user.id),'exp':now()+timedelta(hours=24),'iat':now()}, SECRET, algorithm='HS256')

def user_from_token(token, db):
    try: uid = int(jwt.decode(token, SECRET, algorithms=['HS256'])['sub'])
    except (jwt.PyJWTError, ValueError, KeyError): raise HTTPException(401, 'Invalid or expired token')
    user = db.get(User, uid)
    if not user: raise HTTPException(401, 'Account not found')
    return user

def get_db():
    with SessionLocal() as db: yield db

def current_user(token: str = Depends(__import__('fastapi').security.HTTPBearer()), db: Session=Depends(get_db)):
    return user_from_token(token.credentials, db)

def admin(user: User=Depends(current_user)):
    if not user.is_admin: raise HTTPException(403, 'Admin only')
    return user

def public_user(u): return {'id':u.id,'username':u.username,'xp':u.xp,'coins':u.coins,'level':u.xp//100+1,'is_admin':u.is_admin}

@asynccontextmanager
async def lifespan(app):
    Base.metadata.create_all(engine)
    email = os.environ.get('ADMIN_EMAIL','').strip().lower()
    password = os.environ.get('ADMIN_PASSWORD','')
    if email and password:
        if len(password) < 12: raise RuntimeError('ADMIN_PASSWORD must be at least 12 characters')
        with SessionLocal() as db:
            u = db.scalar(select(User).where(User.email==email))
            if not u:
                username = 'administrator'
                if db.scalar(select(User).where(User.username==username)): username='admin_'+secrets.token_hex(3)
                db.add(User(username=username,email=email,password_hash=hash_password(password),is_admin=True)); db.commit()
            elif not u.is_admin:
                raise RuntimeError('ADMIN_EMAIL belongs to non-admin account; refusing privilege escalation')
    yield

app=FastAPI(title='ذهن تیز API',version='1.0.0',lifespan=lifespan)
origins=[s.strip() for s in os.environ.get('CORS_ORIGINS','http://localhost:5173').split(',') if s.strip()]
app.add_middleware(CORSMiddleware,allow_origins=origins,allow_credentials=True,allow_methods=['GET','POST','PATCH','DELETE'],allow_headers=['Authorization','Content-Type'])

class Register(BaseModel):
    username: str = Field(min_length=3,max_length=40,pattern=r'^[\w\-]+$')
    email: str = Field(max_length=255)
    password: str = Field(min_length=10,max_length=128)
class Login(BaseModel):
    email: str
    password: str
class QuestionIn(BaseModel):
    category: str = Field(min_length=2,max_length=50)
    prompt: str = Field(min_length=3,max_length=1000)
    options: list[str] = Field(min_length=2,max_length=6)
    correct_index: int = Field(ge=0,le=5)
    difficulty: int = Field(default=1,ge=1,le=5)
class AnswerIn(BaseModel):
    question_id: int
    choice: int = Field(ge=0,le=5)
class RoomIn(BaseModel):
    category: str = 'general'
    question_count: int = Field(default=5,ge=1,le=15)
    time_limit: int = Field(default=15,ge=10,le=60)
class ChoiceIn(BaseModel):
    choice: int = Field(ge=0,le=5)

@app.get('/health')
def health(): return {'status':'ok'}
@app.post('/api/auth/register',status_code=201)
def register(payload:Register,db:Session=Depends(get_db)):
    email=payload.email.strip().lower()
    if '@' not in email: raise HTTPException(422,'Invalid email')
    if db.scalar(select(User).where((User.email==email)|(User.username==payload.username))): raise HTTPException(409,'Username or email already exists')
    u=User(username=payload.username,email=email,password_hash=hash_password(payload.password))
    db.add(u);db.commit();db.refresh(u)
    return {'access_token':token_for(u),'token_type':'bearer','user':public_user(u)}
@app.post('/api/auth/login')
def login(payload:Login,db:Session=Depends(get_db)):
    u=db.scalar(select(User).where(User.email==payload.email.strip().lower()))
    if not u or not verify_password(payload.password,u.password_hash): raise HTTPException(401,'Invalid credentials')
    return {'access_token':token_for(u),'token_type':'bearer','user':public_user(u)}
@app.get('/api/me')
def me(user:User=Depends(current_user)):return public_user(user)
@app.get('/api/leaderboard')
def leaderboard(db:Session=Depends(get_db)):
    return [public_user(u) for u in db.scalars(select(User).order_by(User.xp.desc()).limit(50))]
@app.get('/api/questions')
def questions(category:Optional[str]=None,limit:int=Query(10,ge=1,le=30),db:Session=Depends(get_db),user:User=Depends(current_user)):
    stmt=select(Question).where(Question.active==True)
    if category: stmt=stmt.where(Question.category==category)
    items=list(db.scalars(stmt))
    return [{'id':q.id,'category':q.category,'prompt':q.prompt,'options':json.loads(q.options_json),'difficulty':q.difficulty} for q in random.sample(items,min(limit,len(items)))]
@app.post('/api/answers')
def answer(payload:AnswerIn,db:Session=Depends(get_db),user:User=Depends(current_user)):
    q=db.get(Question,payload.question_id)
    if not q or not q.active:raise HTTPException(404,'Question not found')
    if payload.choice>=len(json.loads(q.options_json)):raise HTTPException(422,'Invalid choice')
    # One rewarded attempt per user/question; repeat answers do not award points.
    if db.scalar(select(Attempt).where(Attempt.user_id==user.id,Attempt.question_id==q.id)):
        raise HTTPException(409,'Question already answered')
    correct=payload.choice==q.correct_index
    xp=10*q.difficulty if correct else 0
    db.add(Attempt(user_id=user.id,question_id=q.id,correct=correct,earned_xp=xp))
    user.xp+=xp;user.coins+=5 if correct else 0
    db.commit()
    return {'correct':correct,'correct_index':q.correct_index,'earned_xp':xp,'user':public_user(user)}
@app.post('/api/admin/questions',status_code=201)
def add_question(payload:QuestionIn,db:Session=Depends(get_db),_admin:User=Depends(admin)):
    if payload.correct_index>=len(payload.options):raise HTTPException(422,'correct_index outside options')
    q=Question(category=payload.category,prompt=payload.prompt,options_json=json.dumps(payload.options,ensure_ascii=False),correct_index=payload.correct_index,difficulty=payload.difficulty)
    db.add(q);db.commit();db.refresh(q)
    return {'id':q.id}
@app.get('/api/admin/questions')
def admin_questions(db:Session=Depends(get_db),_admin:User=Depends(admin)):
    return [{'id':q.id,'category':q.category,'prompt':q.prompt,'options':json.loads(q.options_json),'correct_index':q.correct_index,'active':q.active} for q in db.scalars(select(Question).limit(500))]
@app.delete('/api/admin/questions/{question_id}')
def delete_question(question_id:int,db:Session=Depends(get_db),_admin:User=Depends(admin)):
    q=db.get(Question,question_id)
    if not q:raise HTTPException(404,'Not found')
    q.active=False;db.commit();return {'ok':True}
@app.get('/api/admin/users')
def admin_users(db:Session=Depends(get_db),_admin:User=Depends(admin)):
    return [public_user(u) for u in db.scalars(select(User).limit(500))]

# Multiplayer: server-authoritative room, rounds, scoring; WebSocket events for updates.
connections:dict[str,set[WebSocket]]={}
async def broadcast(code,event):
    for ws in list(connections.get(code,set())):
        try:await ws.send_json(event)
        except Exception:connections[code].discard(ws)

def room_data(m):return {'code':m.room_code,'status':m.status,'host_id':m.host_id,'guest_id':m.guest_id,'category':m.category,'question_count':m.question_count,'time_limit':m.time_limit,'round':m.current_round,'host_score':m.host_score,'guest_score':m.guest_score}
@app.post('/api/rooms',status_code=201)
def create_room(payload:RoomIn,db:Session=Depends(get_db),user:User=Depends(current_user)):
    available=list(db.scalars(select(Question).where(Question.active==True,Question.category==payload.category)))
    if len(available)<payload.question_count:raise HTTPException(422,'Not enough questions in category')
    code=secrets.token_hex(3).upper()
    while db.scalar(select(Match).where(Match.room_code==code)):code=secrets.token_hex(3).upper()
    m=Match(room_code=code,host_id=user.id,category=payload.category,question_count=payload.question_count,time_limit=payload.time_limit,questions_json=json.dumps([q.id for q in random.sample(available,payload.question_count)]))
    db.add(m);db.commit();return room_data(m)
@app.get('/api/rooms/{code}')
def room(code:str,db:Session=Depends(get_db),user:User=Depends(current_user)):
    m=db.scalar(select(Match).where(Match.room_code==code.upper()))
    if not m or user.id not in (m.host_id,m.guest_id):raise HTTPException(404,'Room not found')
    return room_data(m)
@app.post('/api/rooms/{code}/join')
async def join(code:str,db:Session=Depends(get_db),user:User=Depends(current_user)):
    m=db.scalar(select(Match).where(Match.room_code==code.upper()))
    if not m:raise HTTPException(404,'Room not found')
    if m.host_id==user.id:raise HTTPException(409,'Host cannot join as guest')
    if m.guest_id and m.guest_id!=user.id:raise HTTPException(409,'Room full')
    if m.status!='waiting':raise HTTPException(409,'Room already started')
    m.guest_id=user.id;db.commit()
    result=room_data(m);await broadcast(m.room_code,{'type':'room_updated','room':result});return result
@app.post('/api/rooms/{code}/start')
async def start(code:str,db:Session=Depends(get_db),user:User=Depends(current_user)):
    m=db.scalar(select(Match).where(Match.room_code==code.upper()))
    if not m or m.host_id!=user.id:raise HTTPException(403,'Host only')
    if not m.guest_id or m.status!='waiting':raise HTTPException(409,'Room not ready')
    m.status='playing';m.round_started_at=int(time.time());db.commit()
    await broadcast(m.room_code,{'type':'room_updated','room':room_data(m)})
    return room_data(m)
@app.get('/api/rooms/{code}/current')
def current_question(code:str,db:Session=Depends(get_db),user:User=Depends(current_user)):
    m=db.scalar(select(Match).where(Match.room_code==code.upper()))
    if not m or user.id not in (m.host_id,m.guest_id):raise HTTPException(403,'Not a player')
    if m.status!='playing':raise HTTPException(409,'Not playing')
    q=db.get(Question,json.loads(m.questions_json)[m.current_round])
    return {'round':m.current_round,'prompt':q.prompt,'options':json.loads(q.options_json),'deadline':m.round_started_at+m.time_limit}
@app.post('/api/rooms/{code}/answer')
async def match_answer(code:str,payload:ChoiceIn,db:Session=Depends(get_db),user:User=Depends(current_user)):
    m=db.scalar(select(Match).where(Match.room_code==code.upper()))
    if not m or user.id not in (m.host_id,m.guest_id):raise HTTPException(403,'Not a player')
    if m.status!='playing':raise HTTPException(409,'Not playing')
    if int(time.time())>m.round_started_at+m.time_limit:raise HTTPException(409,'Round expired')
    if db.scalar(select(MatchAnswer).where(MatchAnswer.match_id==m.id,MatchAnswer.round_index==m.current_round,MatchAnswer.user_id==user.id)):
        raise HTTPException(409,'Already answered')
    q=db.get(Question,json.loads(m.questions_json)[m.current_round]);options=json.loads(q.options_json)
    if payload.choice>=len(options):raise HTTPException(422,'Invalid choice')
    correct=payload.choice==q.correct_index
    points=(100+max(0,m.round_started_at+m.time_limit-int(time.time()))*5) if correct else 0
    db.add(MatchAnswer(match_id=m.id,round_index=m.current_round,user_id=user.id,choice=payload.choice))
    if user.id==m.host_id:m.host_score+=points
    else:m.guest_score+=points
    db.commit()
    await broadcast(m.room_code,{'type':'answer_received','user_id':user.id,'round':m.current_round})
    return {'correct':correct,'points':points}
@app.post('/api/rooms/{code}/next')
async def next_round(code:str,db:Session=Depends(get_db),user:User=Depends(current_user)):
    m=db.scalar(select(Match).where(Match.room_code==code.upper()))
    if not m or m.host_id!=user.id:raise HTTPException(403,'Host only')
    if m.status!='playing':raise HTTPException(409,'Not playing')
    count=db.scalar(select(func.count()).select_from(MatchAnswer).where(MatchAnswer.match_id==m.id,MatchAnswer.round_index==m.current_round))
    if count<2 and int(time.time())<=m.round_started_at+m.time_limit:raise HTTPException(409,'Wait for answers or deadline')
    if m.current_round+1>=m.question_count:
        m.status='finished'
        for uid,score in ((m.host_id,m.host_score),(m.guest_id,m.guest_score)):
            player=db.get(User,uid);player.xp+=score//10;player.coins+=score//100
    else:m.current_round+=1;m.round_started_at=int(time.time())
    db.commit();result=room_data(m)
    await broadcast(m.room_code,{'type':'room_updated','room':result})
    return result
@app.websocket('/ws/rooms/{code}')
async def ws_room(ws:WebSocket,code:str,token:str=Query(...)):
    code=code.upper()
    with SessionLocal() as db:
        try:
            user=user_from_token(token,db)
            m=db.scalar(select(Match).where(Match.room_code==code))
            if not m or user.id not in (m.host_id,m.guest_id):raise HTTPException(403)
        except HTTPException:
            await ws.close(code=1008);return
    await ws.accept();connections.setdefault(code,set()).add(ws)
    try:
        await ws.send_json({'type':'connected','room_code':code})
        while True:await ws.receive_text()  # Updates are generated by HTTP endpoints.
    except WebSocketDisconnect:pass
    finally:connections.get(code,set()).discard(ws)
