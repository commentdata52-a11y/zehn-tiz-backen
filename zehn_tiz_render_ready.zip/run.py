from pathlib import Path
import os
for line in Path('.env').read_text(encoding='utf-8').splitlines():
    if line.strip() and not line.lstrip().startswith('#') and '=' in line:
        k,v=line.split('=',1);os.environ.setdefault(k.strip(),v.strip())
import uvicorn
uvicorn.run('app.main:app',host='127.0.0.1',port=8000,reload=False)
